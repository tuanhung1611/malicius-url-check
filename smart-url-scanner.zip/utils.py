
import re
import requests
import os
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("VT_API_KEY")
VT_URL = "https://www.virustotal.com/api/v3/urls"

def extract_urls(text):
    url_pattern = r'(https?://[^\s]+)'
    return re.findall(url_pattern, text)

def scan_url(url):
    headers = {
        "x-apikey": API_KEY
    }
    data = {"url": url}
    response = requests.post(VT_URL, headers=headers, data=data)
    if response.status_code == 200:
        analysis_url = response.json()["data"]["id"]
        return analysis_url
    else:
        return None

def get_analysis(analysis_id):
    headers = {
        "x-apikey": API_KEY
    }
    response = requests.get(f"{VT_URL}/{analysis_id}", headers=headers)
    if response.status_code == 200:
        data = response.json()["data"]["attributes"]
        stats = data["last_analysis_stats"]
        return stats
    else:
        return None
