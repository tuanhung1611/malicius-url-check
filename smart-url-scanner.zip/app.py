
import tkinter as tk
from tkinter import messagebox
from utils import extract_urls, scan_url, get_analysis

def check_urls():
    text = input_text.get("1.0", "end-1c")
    urls = extract_urls(text)
    if not urls:
        result_text.set("Không tìm thấy URL nào.")
        return

    result = ""
    for url in urls:
        result += f"🔗 {url}\n"
        scan_id = scan_url(url)
        if scan_id:
            stats = get_analysis(scan_id)
            if stats:
                malicious = stats.get("malicious", 0)
                suspicious = stats.get("suspicious", 0)
                result += f"  ❗ Malicious: {malicious} | Suspicious: {suspicious}\n\n"
            else:
                result += "  ⚠️ Không lấy được kết quả.\n\n"
        else:
            result += "  ⚠️ Không gửi được URL đến VirusTotal.\n\n"

    result_text.set(result)

app = tk.Tk()
app.title("Smart URL Scanner")
app.geometry("600x400")

tk.Label(app, text="Nhập văn bản chứa URL:", font=("Arial", 12)).pack()
input_text = tk.Text(app, height=10, width=70)
input_text.pack(pady=10)

tk.Button(app, text="Kiểm tra URL", command=check_urls, bg="#4CAF50", fg="white", font=("Arial", 12)).pack()

result_text = tk.StringVar()
tk.Label(app, textvariable=result_text, justify="left", wraplength=550, font=("Arial", 10)).pack(pady=10)

app.mainloop()
