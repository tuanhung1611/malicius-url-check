# Smart URL Scanner 🔍

Một công cụ thông minh kiểm tra độ an toàn của các URL bằng VirusTotal API. Dự án được viết bằng Python và có giao diện người dùng (GUI).

## 🔧 Tính năng
- Trích xuất link từ văn bản
- Kiểm tra link có độc hại không (VirusTotal)
- Giao diện đơn giản dễ dùng (Tkinter)
- Hiển thị cảnh báo nếu URL nguy hiểm

## 🚀 Cách chạy
1. Cài thư viện:
```bash
pip install -r requirements.txt
```

2. Tạo file `.env` chứa API key:
```
VT_API_KEY=your_virustotal_key
```

3. Chạy ứng dụng:
```bash
python app.py
```

## 📦 Công nghệ sử dụng
- Python
- Tkinter
- requests
- VirusTotal API

